from turtle import color
import flet as ft
from flet import *

style_frame: dict = {
    "expand": True,
    "bgcolor": "#1F2127",
    "border_radius": 18,
    "padding": 20,
    "border": border.all(1, "#44f4f4f4"),
    "alignment": alignment.center,
}

class GraphOne(ft.Container):
    def __init__(self):
        super().__init__(**style_frame)
        data_1 = [
            ft.LineChartData(
                data_points=[
                    ft.LineChartDataPoint(0, 3),
                    ft.LineChartDataPoint(2, 2),
                    ft.LineChartDataPoint(4, 5),
                    ft.LineChartDataPoint(6, 3.1),
                    ft.LineChartDataPoint(8, 4),
                    ft.LineChartDataPoint(10, 3),
                    ft.LineChartDataPoint(11, 4),
                    ft.LineChartDataPoint(14, 4.2),
                    ft.LineChartDataPoint(14.8, 5),
                ],
                stroke_width=5,
                color=ft.colors.CYAN,
                curved=True,
                stroke_cap_round=True,
                gradient=ft.LinearGradient(
                    colors=[ft.colors.CYAN, ft.colors.WHITE]
                ),
            )
        ]
        
        self.content = ft.LineChart(
            data_series=data_1,
            border=ft.border.all(3, ft.colors.with_opacity(0.2, ft.colors.BLACK)),
            horizontal_grid_lines=ft.ChartGridLines(
                interval=1,
                color=ft.colors.with_opacity(0.2, ft.colors.BLACK),
                width=1,
            ),
            vertical_grid_lines=ft.ChartGridLines(
                interval=1,
                color=ft.colors.with_opacity(0.2, ft.colors.BLACK),
                width=1,
            ),
            left_axis=ft.ChartAxis(
                labels=[
                    ft.ChartAxisLabel(
                        value=1,
                        label=ft.Text("10", size=14, color=ft.colors.WHITE)
                    ),
                    ft.ChartAxisLabel(
                        value=2,
                        label=ft.Text("20", size=14, color=ft.colors.WHITE)
                    ),
                    ft.ChartAxisLabel(
                        value=3,
                        label=ft.Text("30", size=14, color=ft.colors.WHITE)
                    ),
                    ft.ChartAxisLabel(
                        value=4,
                        label=ft.Text("40", size=14, color=ft.colors.WHITE)
                    ),
                    ft.ChartAxisLabel(
                        value=5,
                        label=ft.Text("50", size=14, color=ft.colors.WHITE)
                    ),
                    ft.ChartAxisLabel(
                        value=6,
                        label=ft.Text("60", size=14, color=ft.colors.WHITE)
                    ),
                ],
                labels_size=40,
                
            ),
            bottom_axis=ft.ChartAxis(
                labels=[
                    ft.ChartAxisLabel(
                        value=2,
                        label=ft.Text("2", size=16, color=ft.colors.with_opacity(0.8, ft.colors.WHITE))
                    ),
                    ft.ChartAxisLabel(
                        value=6,
                        label=ft.Text("6", size=16, color=ft.colors.with_opacity(0.8, ft.colors.WHITE))
                    ),
                    ft.ChartAxisLabel(
                        value=10,
                        label=ft.Text("10", size=16, color=ft.colors.with_opacity(0.8, ft.colors.WHITE))
                    ),
                    ft.ChartAxisLabel(
                        value=14,
                        label=ft.Text("14", size=16, color=ft.colors.with_opacity(0.8, ft.colors.WHITE))
                    ),
                ],
                labels_size=32,
            ),
            tooltip_bgcolor=ft.colors.with_opacity(0.8, ft.colors.BLACK),
            min_y=0,
            max_y=6,
            min_x=0,
            max_x=15,
            expand=True,
        )

class GraphTwo(ft.Container):
    def __init__(self):
        super().__init__(**style_frame)
        self.content = ft.BarChart(
            bar_groups=[
                ft.BarChartGroup(
                    x=0,
                    bar_rods=[
                        ft.BarChartRod(
                            from_y=0,
                            to_y=40,
                            gradient=ft.LinearGradient(
                                [ft.colors.CYAN, ft.colors.BLUE], rotation=90
                            ),
                            tooltip="$40.00",
                            border_radius=15,
                            width=20
                        ),
                    ],
                ),
                ft.BarChartGroup(
                    x=1,
                    bar_rods=[
                        ft.BarChartRod(
                            from_y=0,
                            to_y=48,
                            gradient=ft.LinearGradient(
                                [ft.colors.CYAN, ft.colors.BLUE], rotation=90
                            ),
                            tooltip="$48.00",
                            border_radius=15,
                            width=20
                        ),
                    ],
                ),
                ft.BarChartGroup(
                    x=2,
                    bar_rods=[
                        ft.BarChartRod(
                            from_y=0,
                            to_y=34,
                            gradient=ft.LinearGradient(
                                [ft.colors.CYAN, ft.colors.BLUE], rotation=90
                            ),
                            tooltip="$34.00",
                            border_radius=15,
                            width=20
                        ),
                    ],
                ),
                ft.BarChartGroup(
                    x=3,
                    bar_rods=[
                        ft.BarChartRod(
                            from_y=0,
                            to_y=68,
                            gradient=ft.LinearGradient(
                                [ft.colors.CYAN, ft.colors.BLUE], rotation=90
                            ),
                            tooltip="$68.00",
                            border_radius=15,
                            width=20
                        ),
                    ],
                ),
                ft.BarChartGroup(
                    x=4,
                    bar_rods=[
                        ft.BarChartRod(
                            from_y=0,
                            to_y=80,
                            gradient=ft.LinearGradient(
                                [ft.colors.CYAN, ft.colors.BLUE], rotation=90
                            ),
                            tooltip="$80.00",
                            border_radius=15,
                            width=20
                        ),
                    ],
                ),
            ],
            border=ft.border.all(1, ft.colors.BLACK38),
            left_axis=ft.ChartAxis(
                labels_size=40,
                title=ft.Text("Traffic", color=ft.colors.WHITE),  # Color blanco para el título del eje izquierdo
                title_size=40,
                labels=[ft.ChartAxisLabel(value=i, label=ft.Text(str(i), color=ft.colors.WHITE)) for i in range(0, 101, 20)]  # Color blanco para las etiquetas del eje
            ),
            bottom_axis=ft.ChartAxis(
                labels=[
                    ft.ChartAxisLabel(
                        value=0,
                        label=ft.Container(ft.Text("A", color=ft.colors.WHITE), padding=10)  # Color blanco
                    ),
                    ft.ChartAxisLabel(
                        value=1,
                        label=ft.Container(ft.Text("B", color=ft.colors.WHITE), padding=10)  # Color blanco
                    ),
                    ft.ChartAxisLabel(
                        value=2,
                        label=ft.Container(ft.Text("C", color=ft.colors.WHITE), padding=10)  # Color blanco
                    ),
                    ft.ChartAxisLabel(
                        value=3,
                        label=ft.Container(ft.Text("D", color=ft.colors.WHITE), padding=10)  # Color blanco
                    ),
                    ft.ChartAxisLabel(
                        value=4,
                        label=ft.Container(ft.Text("E", color=ft.colors.WHITE), padding=10)  # Color blanco
                    ),
                ],
                labels_size=40,
            ),
            horizontal_grid_lines=ft.ChartGridLines(
                color=ft.colors.BLACK38,
                width=1,
                dash_pattern=[3, 3]
            ),
            tooltip_bgcolor=ft.colors.with_opacity(0.5, ft.colors.BLACK),
            max_y=100,
            interactive=True,
            expand=True,
        )

class GraphThree(ft.Container):
    def __init__(self):
        super().__init__(**style_frame)
        self.normal_radius = 100  # Aumentado de 80 a 100
        self.hover_radius = 110  # Aumentado de 90 a 110
        self.normal_title_style = ft.TextStyle(
            size=18,  # Aumentado de 16 a 18
            color=ft.colors.BLACK54,
            weight=ft.FontWeight.BOLD
        )
        self.hover_title_style = ft.TextStyle(
            size=18,  # Aumentado de 16 a 18
            color=ft.colors.WHITE,
            weight=ft.FontWeight.BOLD,
            shadow=ft.BoxShadow(
                blur_radius=2,
                color=ft.colors.BLACK38
            ),
        )
        self.normal_badge_size = 30  # Aumentado de 30 a 35
        
        self.content = ft.PieChart(
            sections=[
                ft.PieChartSection(
                    60,
                    title="60%",
                    title_style=self.normal_title_style,
                    color=ft.colors.GREEN,
                    radius=self.normal_radius,
                    badge=self.badge(ft.icons.VIDEO_CALL, self.normal_badge_size),
                    badge_position=1.1,
                ),
                ft.PieChartSection(
                    15,
                    title="15%",
                    title_style=self.normal_title_style,
                    color=ft.colors.ORANGE,
                    radius=self.normal_radius,
                    badge=self.badge(ft.icons.FACEBOOK, self.normal_badge_size),
                    badge_position=1.1,
                ),
                ft.PieChartSection(
                    12,
                    title="12%",
                    title_style=self.normal_title_style,
                    color=ft.colors.CYAN,
                    radius=self.normal_radius,
                    badge=self.badge(ft.icons.WEB, self.normal_badge_size),
                    badge_position=1.1,
                ),
                ft.PieChartSection(
                    8,
                    title="8%",
                    title_style=self.normal_title_style,
                    color=ft.colors.BLUE,
                    radius=self.normal_radius,
                    badge=self.badge(ft.icons.GAMES, self.normal_badge_size),
                    badge_position=1.1,
                ),
                ft.PieChartSection(
                    5,
                    title="5%",
                    title_style=self.normal_title_style,
                    color=ft.colors.PURPLE,
                    radius=self.normal_radius,
                    badge=self.badge(ft.icons.MY_LIBRARY_MUSIC, self.normal_badge_size),
                    badge_position=1.1,
                ),
            ],
            sections_space=0.5,
            center_space_radius=0,
            on_chart_event=self.on_chart_event,
            expand=True,
        )

    def badge(self, icon, size):
        return ft.Container(
            ft.Icon(icon, color=ft.colors.BLACK, size=20),  # Aumentado el tamaño del icono
            width=size,
            height=size,
            border=ft.border.all(1, ft.colors.BLACK38),
            border_radius=size/2,
            bgcolor=ft.colors.WHITE,
        )

    def on_chart_event(self, event):
        for idx, section in enumerate(self.content.sections):
            if idx == event.section_index:
                section.radius = self.hover_radius
                section.title_style = self.hover_title_style
            else:
                section.radius = self.normal_radius
                section.title_style = self.normal_title_style
        self.content.update()

class GraphFour(ft.Container):
    def __init__(self):
        super().__init__(**style_frame)
        self.normal_border = ft.BorderSide(
            3,  # Aumentado el grosor del borde normal
            ft.colors.with_opacity(0.6, ft.colors.WHITE38)  # Aumentado la opacidad
        )
        self.hovered_border = ft.BorderSide(5, ft.colors.WHITE)  # Aumentado el grosor del borde al pasar el mouse
        self.normal_title_style = ft.TextStyle(
            size=18,  # Aumentado el tamaño del texto
            color=ft.colors.BLACK38,
            weight=ft.FontWeight.BOLD
        )
        self.normal_radius = 60  # Aumentado el radio normal
        self.content = ft.PieChart(
            sections=[
                ft.PieChartSection(
                    26,
                    title="26%",
                    title_style=self.normal_title_style,
                    color=ft.colors.YELLOW,
                    radius=self.normal_radius,
                    border_side=self.normal_border,
                ),
                ft.PieChartSection(
                    13,
                    title="13%",
                    title_style=self.normal_title_style,
                    color=ft.colors.GREEN,
                    radius=self.normal_radius,
                    border_side=self.normal_border,
                ),
                ft.PieChartSection(
                    6,
                    title="6%",
                    title_style=self.normal_title_style,
                    color=ft.colors.RED,
                    radius=self.normal_radius,
                    border_side=self.normal_border,
                ),
                ft.PieChartSection(
                    7,
                    title="7%",
                    title_style=self.normal_title_style,
                    color=ft.colors.BLUE,
                    radius=self.normal_radius,
                    border_side=self.normal_border,
                ),
                ft.PieChartSection(
                    48,
                    title="48%",
                    title_style=self.normal_title_style,
                    color=ft.colors.CYAN,
                    radius=self.normal_radius,
                    border_side=self.normal_border,
                ),                
            ],
            sections_space=3,  # Aumentado el espacio entre secciones
            center_space_radius=50,  # Aumentado el radio del espacio central
            on_chart_event=self.on_chart_event,
            expand=True,
        )

    def on_chart_event(self, event: ft.PieChartEvent):
        for idx, section in enumerate(self.content.sections):
            if idx == event.section_index:
                section.radius = self.normal_radius + 10  # Aumentado el radio al pasar el mouse
                section.border_side = self.hovered_border
            else:
                section.radius = self.normal_radius
                section.border_side = self.normal_border
        self.content.update()

graph_one: ft.Container=GraphOne()
graph_two: ft.Container=GraphTwo()
graph_three: ft.Container=GraphThree()
graph_four: ft.Container=GraphFour()

class InputField(UserControl):
    def __init__(self, width, height, hint_text, icon, password=False):
        super().__init__()
        self.password_visible = password
        self.textfield = TextField(
            hint_text=hint_text,
            border=InputBorder.NONE,
            color="white",
            hint_style=TextStyle(
                color="white",
            ),
            width=width / 5 * 4,
            height=height,
            bgcolor="transparent",
            text_style=TextStyle(size=18, weight="w400"),
            password=self.password_visible,
        )
        self.icon_button = Icon(
            icon,
            color="white",
        )

        self.body = Container(
            Row(
                [
                    self.textfield,
                    GestureDetector(
                        on_tap=self.toggle_password_visibility,
                        content=self.icon_button,
                    ),
                ]
            ),
            width=width,
            height=height,
            border=border.all(1, "#44f4f4f4"),
            border_radius=18,
            bgcolor="transparent",
            alignment=alignment.center,
        )

    def toggle_password_visibility(self, e):
        self.password_visible = not self.password_visible
        self.textfield.password = self.password_visible
        self.icon_button.icon = (
            icons.LOCK_OPEN_ROUNDED if not self.password_visible else icons.LOCK_ROUNDED
        )
        self.update()

    def build(self):
        return self.body


# class LoginApp(UserControl):
#     def __init__(self):
#         super().__init__()
#         self.username_field = InputField(
#             width=320, height=60, hint_text="Usuario", icon=icons.PERSON_ROUNDED
#         )
#         self.password_field = InputField(
#             width=320,
#             height=60,
#             hint_text="Contraseña",
#             icon=icons.LOCK_ROUNDED,
#             password=True,
#         )
#         self.remember_me = Checkbox(value=False, label="Recordar ingreso")

#     def read_credentials(self):
#         with open("credentials.txt", "r") as f:
#             credentials = {}
#             for line in f.readlines():
#                 user, password = line.strip().split(":")
#                 credentials[user] = password
#         return credentials

#     def save_remember_me(self, username, password):
#         if self.remember_me.value:
#             with open("remember_me.txt", "w") as f:
#                 f.write(f"{username}:{password}")

#     def check_remember_me(self):
#         try:
#             with open("remember_me.txt", "r") as f:
#                 username, password = f.read().strip().split(":")
#                 return username, password
#         except FileNotFoundError:
#             return None, None

#     def validate_credentials(self, e):
#         credentials = self.read_credentials()
#         username = self.username_field.textfield.value
#         password = self.password_field.textfield.value

#         if credentials.get(username) == password:
#             self.save_remember_me(username, password)
#             self.redirect_to_dashboard()
#         else:
#             self.show_error("Usuario o contraseña incorrectos.")

#     def redirect_to_dashboard(self):
#         self.page.clean()
#         load_dashboard(self.page)

#     def show_error(self, message):
#         error_message = Text(message, color="red", size=16)
#         self.page.add(error_message)

#     def build(self):
#         remembered_user, remembered_pass = self.check_remember_me()
#         if remembered_user and remembered_pass:
#             self.username_field.textfield.value = remembered_user
#             self.password_field.textfield.value = remembered_pass
#             self.redirect_to_dashboard()

#     def build(self):
#         return Container(
#             Stack(
#                 [
#                     Image(src="assets/bg.png"),
#                     Container(
#                         alignment=alignment.center,
#                         margin=margin.only(top=150),
#                         content=Container(
#                             Column(
#                                 [
#                                     Row(
#                                         [
#                                             Text(
#                                                 "Iniciar sesión",
#                                                 color="white",
#                                                 weight="w700",
#                                                 size=26,
#                                                 text_align="center",
#                                             ),
#                                         ],
#                                         alignment=MainAxisAlignment.CENTER,
#                                     ),
#                                     Row(
#                                         [self.username_field],
#                                         alignment=MainAxisAlignment.CENTER,
#                                     ),
#                                     Row(
#                                         [self.password_field],
#                                         alignment=MainAxisAlignment.CENTER,
#                                     ),
#                                     Row(
#                                         [
#                                             Checkbox(value=False),
#                                             Text(
#                                                 "Recordar ingreso",
#                                                 color="white",
#                                                 size=14,
#                                             ),
#                                         ],
#                                         alignment=MainAxisAlignment.CENTER,
#                                     ),
#                                     Row(
#                                         [
#                                             ElevatedButton(
#                                                 "Ingresar",
#                                                 color="black",
#                                                 bgcolor="gray",
#                                                 width=300,
#                                                 height=60,
#                                                 on_click=self.validate_credentials,
#                                             )
#                                         ],
#                                         alignment=MainAxisAlignment.CENTER,
#                                     ),
#                                 ],
#                                 alignment=MainAxisAlignment.CENTER,
#                             ),
#                             width=400,
#                             height=400,
#                             border_radius=18,
#                             blur=Blur(10, 12, BlurTileMode.MIRROR),
#                             border=border.all(1, "#44f4f4f4"),
#                             bgcolor="#10f4f4f4",
#                             alignment=alignment.center,
#                         ),
#                     ),
#                 ]
#             )
#         )

def logout(e):
    print("Cerrando sesión...")
    # Aquí puedes agregar la lógica para cerrar la sesión

def load_dashboard(page):
    #page.theme_mode = ft.ThemeMode.SYSTEM
    page.bgcolor = ft.colors.BLACK26
    page.scroll = "adaptive"
    page.update()

    dispositivos = [
        {
            "nombre": "Dispositivo 1",
            "ip": "192.168.1.10",
            "mac": "AA:BB:CC:DD:EE:01",
            "tiempo": "2h 15m",
            "ancho_banda": "20 Mbps",
            "prioridad": "9",
        },
        {
            "nombre": "Dispositivo 2",
            "ip": "192.168.1.11",
            "mac": "AA:BB:CC:DD:EE:02",
            "tiempo": "1h 45m",
            "ancho_banda": "10 Mbps",
            "prioridad": "7",
        },
        {
            "nombre": "Dispositivo 3",
            "ip": "192.168.1.12",
            "mac": "AA:BB:CC:DD:EE:03",
            "tiempo": "3h 10m",
            "ancho_banda": "30 Mbps",
            "prioridad": "17",
        },
        {
            "nombre": "Dispositivo 4",
            "ip": "192.168.100.102",
            "mac": "AA:BB:CC:DD:EE:04",
            "tiempo": "2h 23m",
            "ancho_banda": "27 Mbps",
            "prioridad": "15",
        },
        {
            "nombre": "Dispositivo 5",
            "ip": "192.168.100.103",
            "mac": "AA:BB:CC:DD:EE:05",
            "tiempo": "1h 45m",
            "ancho_banda": "15 Mbps",
            "prioridad": "8",
        },
        {
            "nombre": "Dispositivo 6",
            "ip": "192.168.100.104",
            "mac": "AA:BB:CC:DD:EE:06",
            "tiempo": "4h 10m",
            "ancho_banda": "40 Mbps",
            "prioridad": "20",
        },
        {
            "nombre": "Dispositivo 7",
            "ip": "192.168.100.105",
            "mac": "AA:BB:CC:DD:EE:07",
            "tiempo": "3h 30m",
            "ancho_banda": "22 Mbps",
            "prioridad": "12",
        },
        {
            "nombre": "Dispositivo 8",
            "ip": "192.168.100.106",
            "mac": "AA:BB:CC:DD:EE:08",
            "tiempo": "5h 05m",
            "ancho_banda": "35 Mbps",
            "prioridad": "18",
        },
        {
            "nombre": "Dispositivo 9",
            "ip": "192.168.100.107",
            "mac": "AA:BB:CC:DD:EE:09",
            "tiempo": "2h 50m",
            "ancho_banda": "18 Mbps",
            "prioridad": "10",
        },
        {
            "nombre": "Dispositivo 10",
            "ip": "192.168.100.108",
            "mac": "AA:BB:CC:DD:EE:10",
            "tiempo": "6h 15m",
            "ancho_banda": "45 Mbps",
            "prioridad": "22",
        },
        {
            "nombre": "Dispositivo 11",
            "ip": "192.168.100.109",
            "mac": "AA:BB:CC:DD:EE:11",
            "tiempo": "1h 55m",
            "ancho_banda": "12 Mbps",
            "prioridad": "6",
        },
        {
            "nombre": "Dispositivo 12",
            "ip": "192.168.100.110",
            "mac": "AA:BB:CC:DD:EE:12",
            "tiempo": "4h 40m",
            "ancho_banda": "33 Mbps",
            "prioridad": "16",
        },
        {
            "nombre": "Dispositivo 13",
            "ip": "192.168.100.111",
            "mac": "AA:BB:CC:DD:EE:13",
            "tiempo": "5h 20m",
            "ancho_banda": "40 Mbps",
            "prioridad": "20",
        },
        {
            "nombre": "Dispositivo 14",
            "ip": "192.168.100.112",
            "mac": "AA:BB:CC:DD:EE:14",
            "tiempo": "3h 15m",
            "ancho_banda": "25 Mbps",
            "prioridad": "12",
        },
        {
            "nombre": "Dispositivo 15",
            "ip": "192.168.100.113",
            "mac": "AA:BB:CC:DD:EE:15",
            "tiempo": "6h 30m",
            "ancho_banda": "50 Mbps",
            "prioridad": "24",
        },
        {
            "nombre": "Dispositivo 16",
            "ip": "192.168.100.114",
            "mac": "AA:BB:CC:DD:EE:16",
            "tiempo": "2h 10m",
            "ancho_banda": "15 Mbps",
            "prioridad": "8",
        },
        {
            "nombre": "Dispositivo 17",
            "ip": "192.168.100.115",
            "mac": "AA:BB:CC:DD:EE:17",
            "tiempo": "4h 50m",
            "ancho_banda": "35 Mbps",
            "prioridad": "18",
        },
        {
            "nombre": "Dispositivo 18",
            "ip": "192.168.100.116",
            "mac": "AA:BB:CC:DD:EE:18",
            "tiempo": "1h 40m",
            "ancho_banda": "10 Mbps",
            "prioridad": "6",
        },
        {
            "nombre": "Dispositivo 19",
            "ip": "192.168.100.117",
            "mac": "AA:BB:CC:DD:EE:19",
            "tiempo": "5h 10m",
            "ancho_banda": "42 Mbps",
            "prioridad": "21",
        },
        {
            "nombre": "Dispositivo 20",
            "ip": "192.168.100.118",
            "mac": "AA:BB:CC:DD:EE:20",
            "tiempo": "3h 20m",
            "ancho_banda": "28 Mbps",
            "prioridad": "14",
        },
        {
            "nombre": "Dispositivo 21",
            "ip": "192.168.100.119",
            "mac": "AA:BB:CC:DD:EE:21",
            "tiempo": "6h 45m",
            "ancho_banda": "55 Mbps",
            "prioridad": "26",
        },
        {
            "nombre": "Dispositivo 22",
            "ip": "192.168.100.120",
            "mac": "AA:BB:CC:DD:EE:22",
            "tiempo": "2h 25m",
            "ancho_banda": "18 Mbps",
            "prioridad": "10",
        },
        {
            "nombre": "Dispositivo 23",
            "ip": "192.168.100.121",
            "mac": "AA:BB:CC:DD:EE:23",
            "tiempo": "4h 55m",
            "ancho_banda": "38 Mbps",
            "prioridad": "19",
        },
        {
            "nombre": "Dispositivo 24",
            "ip": "192.168.100.122",
            "mac": "AA:BB:CC:DD:EE:24",
            "tiempo": "1h 50m",
            "ancho_banda": "12 Mbps",
            "prioridad": "7",
        },
        {
            "nombre": "Dispositivo 25",
            "ip": "192.168.100.123",
            "mac": "AA:BB:CC:DD:EE:25",
            "tiempo": "5h 35m",
            "ancho_banda": "45 Mbps",
            "prioridad": "23",
        },
    ]

    def change_view(index):
        content.controls.clear()
        if index == 0:
            content.controls.append(
                ft.Column(
                    [
                        ft.Container(
                            content=ft.Text(
                                "Monitorear Red",
                                theme_style=ft.TextThemeStyle.TITLE_LARGE,
                                text_align=ft.TextAlign.CENTER,
                            ),
                            alignment=ft.alignment.center,
                            padding=ft.padding.only(top=10, bottom=10),
                            margin=ft.margin.only(right=30, top=20, bottom=20),
                            bgcolor=ft.colors.SURFACE_VARIANT,
                            width=float("inf"),
                            border_radius=ft.border_radius.all(10),
                        ),
                        ft.Text("Gráficos estadísticos e historial de cambios"),
                        ft.Container(
                            ft.Image(
                                src="C:/Users/cueto/Desktop/Flet.py/first-flet-app/pojetoDemo/assets/portada.png",
                                width=4000,
                                height=300,
                            ),
                            height=580,
                        ),
                    ]
                )
            )
        elif index == 1:
            content.controls.append(
                ft.Column(
                    [
                        ft.Container(
                            content=ft.Text(
                                "Estadisticas de Trafico",
                                theme_style=ft.TextThemeStyle.TITLE_LARGE,
                                text_align=ft.TextAlign.CENTER,
                            ),
                            alignment=ft.alignment.center,
                            padding=ft.padding.only(top=10, bottom=10),
                            margin=ft.margin.only(right=30, top=20, bottom=20),
                            bgcolor=ft.colors.SURFACE_VARIANT,
                            width=float("inf"),
                            border_radius=ft.border_radius.all(10),
                        ),
                        # ft.Container(
                        #     content=ft.Text(
                        #         "Gráfico de barras del historial de paquetes por tipo",
                        #         text_align=ft.TextAlign.CENTER,
                        #     ),
                        #     alignment=ft.alignment.center,
                        #     width=float("inf"),
                        # ),
                        ft.Row(
                            [
                                ft.Column(
                                    expand=True,
                                    controls=[
                                        ft.Container(graph_one, height=300, margin=ft.margin.only(left=-15)),
                                        ft.Container(graph_two, height=300, margin=ft.margin.only(left=-15))
                                    ]
                                ),
                                ft.Column(
                                    expand=True,
                                    controls=[
                                        ft.Container(graph_three, height=300, margin=ft.margin.only(right=20)),
                                        ft.Container(graph_four, height=300, margin=ft.margin.only(right=20))
                                    ]
                                )
                            ]
                        )
                    ]
                )
            )
        elif index == 2:
            def cerrar_modal(e):
                modal.open = False
                page.update()

            def abrir_modal(dispositivo):
                def confirmar_click(e):
                    dispositivo['ancho_banda'] = ancho_banda_control.value
                    dispositivo['prioridad'] = prioridad_control.value
                    nbw = dispositivo['ancho_banda']
                    np = dispositivo['prioridad']
                    print(f"Ancho de banda nuevo: {nbw}")
                    print(f"Prioridad nueva: {np}")
                    modal.open = False  # Cerrar el modal después de confirmar
                    page.update()
                
                ancho_banda_control = ft.TextField(label="Ancho de banda", value=dispositivo["ancho_banda"])
                prioridad_control = ft.TextField(label="Prioridad", value=dispositivo["prioridad"])

                global modal
                modal = ft.AlertDialog(
                    title=ft.Text("Modificar dispositivo"),
                    content=ft.Container(
                        content=ft.Column(
                            [
                                ft.Text(f"Dispositivo: {dispositivo['nombre']}"),
                                ancho_banda_control,
                                prioridad_control,
                            ],
                            spacing=10,
                        ),
                        height=200,  # Ajustamos la altura del contenido del modal
                    ),
                    actions=[
                        ft.Container(
                            content=ft.Row(
                                [
                                    ft.TextButton("Cancelar", on_click=cerrar_modal),
                                    ft.TextButton("Confirmar", on_click=confirmar_click),
                                ],
                                alignment=ft.MainAxisAlignment.CENTER,
                            ),
                            alignment=ft.alignment.center,
                        ),
                    ],
                )
                
                page.dialog = modal
                modal.open = True
                page.update()
            cards = [
                ft.Card(
                    content=ft.GestureDetector(
                        on_tap=lambda e, d=d: abrir_modal(d),
                        content=ft.Container(
                            content=ft.Column(
                                [
                                    ft.Text(f"Nombre: {d['nombre']}", style="titleMedium"),
                                    ft.Text(f"IP: {d['ip']}"),
                                    ft.Text(f"MAC: {d['mac']}"),
                                    ft.Text(f"Tiempo de conexión: {d['tiempo']}"),
                                    ft.Text(f"Ancho de banda usada: {d['ancho_banda']}"),
                                    ft.Text(f"Prioridad asignada: {d['prioridad']}"),
                                ],
                                spacing=5,
                                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                            ),
                            padding=ft.padding.all(10),
                            border_radius=10,
                            bgcolor=ft.colors.SURFACE_VARIANT,
                        ),
                    ),
                    elevation=5,
                    width=300,
                    height=150,
                )
                for d in dispositivos
            ]
            
            contenedor_scrollable = ft.Container(
                content=ft.Column(
                    [
                        ft.Row(
                            controls=cards,
                            wrap=True,
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=20,
                        )
                    ],
                    scroll=ft.ScrollMode.AUTO,
                ),
                height=320,  # Ajusta esta altura según tus necesidades
                width=float("inf"),
            )


            content.controls.append(
                ft.Column(
                    [
                        ft.Container(
                            content=ft.Text(
                                "Dispositivos Conectados",
                                theme_style=ft.TextThemeStyle.TITLE_LARGE,
                                text_align=ft.TextAlign.CENTER,
                            ),
                            alignment=ft.alignment.center,
                            padding=ft.padding.only(top=10, bottom=10),
                            margin=ft.margin.only(right=30, top=20, bottom=20),
                            bgcolor=ft.colors.SURFACE_VARIANT,
                            width=float("inf"),
                            border_radius=ft.border_radius.all(10),
                        ),
                        ft.Container(
                            content=ft.AnimatedSwitcher(
                                content=ft.Column(
                                    [
                                        ft.Row(
                                            controls=cards,
                                            wrap=True,
                                            alignment=ft.MainAxisAlignment.CENTER,
                                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                                            spacing=20,
                                        )
                                    ],
                                    scroll=ft.ScrollMode.AUTO,
                                ),
                                transition=ft.AnimatedSwitcherTransition.SCALE,
                                duration=300,
                                switch_in_curve=ft.AnimationCurve.EASE_IN,
                                switch_out_curve=ft.AnimationCurve.EASE_OUT,
                            ),
                            alignment=ft.alignment.center,
                            width=float("inf"),
                            height=610,  # Ajusta esta altura según tus necesidades
                        ),
                    ]
                )
            )
        elif index == 3:
            content.controls.append(
                ft.Column(
                    [
                        ft.Container(
                            content=ft.Text(
                                "Notificaciones",
                                theme_style=ft.TextThemeStyle.TITLE_LARGE,
                                text_align=ft.TextAlign.CENTER,
                            ),
                            alignment=ft.alignment.center,
                            padding=ft.padding.only(top=10, bottom=10),
                            margin=ft.margin.only(right=30, top=20, bottom=20),
                            bgcolor=ft.colors.SURFACE_VARIANT,
                            width=float("inf"),
                            border_radius=ft.border_radius.all(10),
                        ),
                        ft.Text("Aquí puedes ver tus notificaciones recientes"),
                        ft.Container(
                            content=ft.ListView(
                                controls=[
                                    ft.ListTile(
                                        leading=ft.Icon(ft.icons.NOTIFICATIONS),
                                        title=ft.Text("Nueva actualización disponible"),
                                        subtitle=ft.Text("Hace 2 horas"),
                                    ),
                                    ft.ListTile(
                                        leading=ft.Icon(ft.icons.WARNING),
                                        title=ft.Text("Alerta de seguridad"),
                                        subtitle=ft.Text("Hace 1 día"),
                                    ),
                                    ft.ListTile(
                                        leading=ft.Icon(ft.icons.INFO),
                                        title=ft.Text("Informe semanal listo"),
                                        subtitle=ft.Text("Hace 3 días"),
                                    ),
                                ],
                                expand=1,
                            ),
                            height=580,
                        ),
                    ]
                )
            )
        page.update()

    sidebar = ft.Container(
        content=ft.Column(
            [
                ft.Container(
                    content=ft.NavigationRail(
                        selected_index=0,
                        on_change=lambda e: change_view(e.control.selected_index),
                        destinations=[
                            ft.NavigationRailDestination(
                                icon=ft.icons.INSIGHTS,
                                label="Monitoreo",
                                padding=ft.padding.only(top=75),
                            ),
                            ft.NavigationRailDestination(
                                icon=ft.icons.GRAPHIC_EQ_OUTLINED,
                                label="Estadísticas",
                                padding=ft.padding.symmetric(vertical=15)
                            ),
                            ft.NavigationRailDestination(
                                icon=ft.icons.DEVICES,
                                label="Dispositivos",
                                padding=ft.padding.symmetric(vertical=15)
                            ),
                            ft.NavigationRailDestination(
                                icon=ft.icons.NOTIFICATIONS,
                                label="Notificaciones",
                                padding=ft.padding.symmetric(vertical=15)
                            ),
                        ],
                        extended=False,
                        min_width=100,
                        min_extended_width=200,
                    ),
                    expand=True,
                    height=500,  # Ajustar este valor
                ),
                ft.Container(
                    content=ft.IconButton(
                        icon=ft.icons.LOGOUT_SHARP,
                        on_click=logout,
                        icon_color=ft.colors.WHITE,
                        icon_size=24,
                    ),
                    margin=ft.margin.only(top=0, bottom=5),
                    alignment=ft.alignment.center
                )
            ],
            expand=True,
        ),
        width=100,
        bgcolor=ft.colors.GREY_400,
        border_radius=10,
        margin=ft.margin.only(left=15, right=15, bottom=15, top=-15),
        
    )

    content = ft.Column(expand=True)

    # change_view(0)
    change_view(0)

    page.add(
        ft.Row(
            [
                sidebar,
                ft.VerticalDivider(width=1),
                ft.Container(content, expand=True),
            ],
            expand=True,
        )
    )


def main(page: ft.Page):

    page.padding = 0
    page.window.resizable = True
    page.vertical_alignment = "center"
    page.horizontal_alignment = "center"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.bgcolor = ft.colors.GREY_300
    page.scroll = "adaptive"
    page.update()

    # login_app = LoginApp()
    # page.add(login_app)
    load_dashboard(page)


ft.app(target=main)

